import React from 'react'
import Accordion from 'react-bootstrap/Accordion';
function Faqs() {
  return (
         <div className="container text-center mt-5 mb-5">
              
               <h1   > FAQs</h1>
               <hr className="w-25 m-auto" />
              
         <br/>
         <Accordion>
         <Accordion.Item eventKey="0">
           <Accordion.Header>Where can I charge ?</Accordion.Header>
           <Accordion.Body>
             Most EVs come with a 110-volt “Level 1”
             cordset that can be plugged in to a typical
             household outlet. <br />
             For quicker charging, homeowners can
             install a 240-volt “Level 2” unit, often with
             little or no required electrical upgrades
             because most homes have 240-volt service
             for appliances like dryers and electric ranges. <br />
             More and more workplaces are also
             installing charging units or making 110-volt
             outlets available to employees and visitors.
           </Accordion.Body>
         </Accordion.Item>
         <Accordion.Item eventKey="1">
           <Accordion.Header> How long does it take to recharge?</Accordion.Header>
           <Accordion.Body>
             <strong>Level 1</strong> charging units add 2–5 miles of
             range per hour of charging. <br />
             <strong>Level 2 </strong>  charging units add 10–30 miles of
             range per hour of charging. <br />
             <strong>DC fast</strong> units can add 100–200+ miles of
             range in as little as 30 minutes.
           </Accordion.Body>
         </Accordion.Item>
         <Accordion.Item eventKey="2">
           <Accordion.Header>What about safety and maintenan?</Accordion.Header>
           <Accordion.Body>
             EVs and their battery packs undergo the
             same rigorous safety testing as conventional vehicles sold in the United States and
             must meet Federal Motor Vehicle Safety
             Standards.
             A manufacturer’s battery warranty typically
             covers 8 years/100,000 miles. Expected
             battery lifetime is 10–12 years under
             normal operating conditions. Check with
             your vehicle’s manufacturer for vehicle and
             battery warranty information.
           </Accordion.Body>
         </Accordion.Item>
       </Accordion>
       </div>
  )
}

export default Faqs;