import React from 'react'
 
function OurService() {
  return (
    <>
         <div>
         <br className="se my-10" id="services" />
         <br />
         <section className="services py-2 bg-Warning text-center ">   
           <div className="container">
              
               <h1   > Our<span className="text-pink"> Services</span></h1>
               <hr className="w-25 m-auto" />
              
         <br/>
              
             <div className="row">
               <div className="col-sm-12 col-md-5 col-lg-5 col-12    text-start">
                 <div className="card " style={{ width: '18rem', height: 'fit-content' }}>
                   <img src="assets/wolfspeed.gif" className="card-img-top " alt="..." />
                   <div className="card-body">
                     <h5 className="card-title">Find Station</h5>
                    </div>
                 </div>
               </div>
               <div className="col-sm-12 col-md-4 col-lg-4 col-12     text-start">
                 <div className="card" style={{ width: '18rem' }}>
                   <img src="assets/car_loop.gif" className="card-img-top" alt="..." />
                   <div className="card-body">
                     <h5 className="card-title">Booking</h5>
  
                   </div>
                 </div>
               </div>
               <div className="col-sm-12 col-md-3 col-lg-3 col-12   text-start">
                 <div className="card" style={{ width: '18rem' }}>
                   <img src="assets/car charger.gif" className="card-img-top " alt="..." />
                   <div className="card-body">
                     <h5 className="card-title">Charging Calulator</h5>
                    </div>
                 </div>
               </div>
             </div>
           </div>
          
         </section>
       </div>
       </>
  )
}

export default OurService