import React from 'react'
import { Alert } from 'react-bootstrap'

function FindStation() {
         return (
                  <>
                           <div className="container mt-5 text-center">
                                    <div className="row">
                                             <div className="col-md-12"> <Alert ><h1>Find Station</h1></Alert></div>
                                             <div className="row  text-center fs-1">
                                             </div>
                                             <br />
                                             <iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d1943455.1587219352!2d74.16158964414498!3d17.940973775857724!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1selectric%20vehicle%20charging%20station%20google%20map!5e0!3m2!1sen!2sin!4v1671475282155!5m2!1sen!2sin" width={600} height={450} style={{ border: 0 }} allowFullScreen loading="lazy" referrerPolicy="no-referrer-when-downgrade" />
                                    </div>
                           </div>
                  </>
         )
}

export default FindStation