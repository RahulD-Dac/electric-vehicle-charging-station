import { Container } from "react-bootstrap";
import Masthead from "./Masthead";
import OurTeam from "./OurTeam";
import Services from "./Services";
import ContactForm from "./ContactForm";
import Faqs from "./Faqs";
import OurService from "./OurService";
import Client from "./Client";
 
 export function Home() {
        return (
                <>
                        <Container>
                                <Masthead />
                                 <Services />
                                 <OurService />
                                <OurTeam />
                                <Client />
                                <Faqs />
                       
                                <ContactForm ></ContactForm>
                        </Container>
                 </>
        )

}