import React from 'react'

function Services() {
  return (
    <>
      <section className="page-section" id="services">
        <div className="container">
          <div className="text-center">
            <h2 className="section-heading text-uppercase">Services</h2>
            <h3 className="section-subheading text-muted">These Services mostly help User.</h3>
          </div>
          <div className="row text-center">
            <div className="col-md-4">
              <span className="fa-stack fa-4x">
                <i className="fas fa-circle fa-stack-2x text-primary" />
                <i className="fas fa-shopping-cart fa-stack-1x fa-inverse" />
              </span>
              <h4 className="my-3">E-Booking</h4>
              <p className="text-muted">Booking you Appointment.</p>
            </div>
            <div className="col-md-4">
              <span className="fa-stack fa-4x">
                <i className="fas fa-circle fa-stack-2x text-primary" />
                <i className="fas fa-laptop fa-stack-1x fa-inverse" />
              </span>
              <h4 className="my-3">Find Map</h4>
              <p className="text-muted">Find Address for you Charging Station.</p>
            </div>
            <div className="col-md-4">
              <span className="fa-stack fa-4x">
                <i className="fas fa-circle fa-stack-2x text-primary" />
                <i className="fas fa-lock fa-stack-1x fa-inverse" />
              </span>
              <h4 className="my-3">Web Security</h4>
              <p className="text-muted">This Website Provide the Security to Client.</p>
            </div>
          </div>
        </div>
      </section>
      {/* Portfolio Grid*/}
      <section className="page-section bg-light" id="portfolio">
        <div className="container">
          <div className="text-center">
            <h2 className="section-heading text-uppercase">Electric Vehicle Info
            </h2>
            <h3 className="section-subheading text-muted">Several national and local governments have established EV incentives to reduce the purchase price of electric cars and other plug-ins.</h3>
          </div>
          <div className="row">
            <div className="col-lg-4 col-sm-6 mb-4">

              <div className="portfolio-item">
                <a className="portfolio-link" data-bs-toggle="modal" href="#portfolioModal2">
                  <div className="portfolio-hover">
                    <div className="portfolio-hover-content"><i className="fas fa-plus fa-3x" /></div>
                  </div>
                  <img className="img-fluid" src="assets/img/portfolio/2.jpg" alt="..." />
                </a>
                <div className="portfolio-caption">
                  <div className="portfolio-caption-heading">Electric Vehicle Purchase Cost</div>
                  <div className="portfolio-caption-subheading text-muted">Car Cost</div>
                </div>
              </div>
            </div>
            <div className="col-lg-4 col-sm-6 mb-4">
              {/* Portfolio item 3*/}
              <div className="portfolio-item">
                <a className="portfolio-link" data-bs-toggle="modal" href="#portfolioModal3">
                  <div className="portfolio-hover">
                    <div className="portfolio-hover-content"><i className="fas fa-plus fa-3x" /></div>
                  </div>
                  <img className="img-fluid" src="assets/img/portfolio/3.jpg" alt="..." />
                </a>
                <div className="portfolio-caption">
                  <div className="portfolio-caption-heading">Finish</div>
                  <div className="portfolio-caption-subheading text-muted">Identity</div>
                </div>
              </div>
            </div>
            <div className="col-lg-4 col-sm-6 mb-4 mb-lg-0">


              <div className="portfolio-item">
                <a className="portfolio-link" data-bs-toggle="modal" href="#portfolioModal6">
                  <div className="portfolio-hover">
                    <div className="portfolio-hover-content"><i className="fas fa-plus fa-3x" /></div>
                  </div>
                  <img className="img-fluid" src="assets/img/portfolio/6.jpg" alt="..." />
                </a>
                <div className="portfolio-caption">
                  <div className="portfolio-caption-heading">Charging Station</div>
                  <div className="portfolio-caption-subheading text-muted">Charging</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div class="portfolio-modal modal fade" id="portfolioModal6" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="close-modal" data-bs-dismiss="modal"><img src="assets/img/close-icon.svg" alt="Close modal" /></div>
            <div class="container">
              <div class="row justify-content-center">
                <div class="col-lg-8">
                  <div class="modal-body">
                    <h2 class="text-uppercase">Charging Station</h2>
                    <p class="item-intro text-muted">A charging station, also known as a charge point or electric vehicle supply equipment (EVSE), is a piece of equipment that supplies electrical power for charging plug-in electric vehicles (including electric cars, electric trucks, electric buses, neighborhood electric vehicles, and plug-in hybrids).</p>
                    <img class="img-fluid d-block mx-auto" src="assets/img/portfolio/6.jpg" alt="..." />
                    <p>Charging stations provide connectors that conform to a variety of international standards. DC charging stations are commonly equipped with multiple connectors to be able to charge a wide variety of vehicles that utilize competing standards.

                      Public charging stations are typically found street-side or at retail shopping centers, government facilities, and other parking areas. Private charging stations are typically found at residences, workplaces, and hotels.</p>
                    <ul class="list-inline">


                    </ul>
                    <button class="btn btn-primary btn-xl text-uppercase" data-bs-dismiss="modal" type="button">
                      <i class="fas fa-xmark me-1"></i>
                      Close Project
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Portfolio item 2 modal popup*/}
      <div className="portfolio-modal modal fade" id="portfolioModal2" tabIndex={-1} role="dialog" aria-hidden="true">
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="close-modal" data-bs-dismiss="modal"><img src="assets/img/close-icon.svg" alt="Close modal" /></div>
            <div className="container">
              <div className="row justify-content-center">
                <div className="col-lg-8">
                  <div className="modal-body">
                    {/* Project details*/}
                    <h2 className="text-uppercase">Electric Vehicle Purchase cost
                    </h2>
                    <p className="item-intro text-muted">Updated price is for labour charge only, it does not include any spare part replacement charge..</p>
                    <img className="img-fluid d-block mx-auto" src="assets/img/portfolio/2.jpg" alt="..." />
                    <p>Several national and local governments have established EV incentives to reduce the purchase price of electric cars and other plug-ins

                      As of 2020, the electric vehicle battery is more than a quarter of the total cost of the car. Purchase prices are expected to drop below those of new ICE cars when battery costs fall below US$100 per kWh, which is forecast to be in the mid-2020s.

                      Leasing or subscriptions are popular in some countries,  depending somewhat on national taxes and subsidies, and end of lease cars are expanding the second hand market.

                      In a June 2022 report by AlixPartners, the cost for raw materials on an average EV rose from $3,381 in March 2020 to $8,255 in May 2022. The cost increase voice is attributed mainly to lithium, nickel, and cobalt.
<br/>
<hr />
                      <strong>Running costs </strong>
                      Electricity almost always costs less than gasoline per kilometer travelled, but the price of electricity often varies depending on where and what time of day the car is charged. Cost savings are also affected by the price of gasoline which can vary by location. </p>
                    <ul className="list-inline">
                       
                    </ul>
                    <button className="btn btn-primary btn-xl text-uppercase" data-bs-dismiss="modal" type="button">
                      <i className="fas fa-xmark me-1" />
                      Close Project
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Portfolio item 3 modal popup*/}
      <div className="portfolio-modal modal fade" id="portfolioModal3" tabIndex={-1} role="dialog" aria-hidden="true">
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="close-modal" data-bs-dismiss="modal"><img src="assets/img/close-icon.svg" alt="Close modal" /></div>
            <div className="container">
              <div className="row justify-content-center">
                <div className="col-lg-8">
                  <div className="modal-body">
                    {/* Project details*/}
                    <h2 className="text-uppercase">Charging</h2>
                    <p className="item-intro text-muted">Connectors.</p>
                    <img className="img-fluid d-block mx-auto" src="assets/img/portfolio/3.jpg" alt="..." />
                    <p>
                    <br/>
<strong>Container : -</strong>
                    Most electric cars use a wired connection to supply electricity for recharging. Electric vehicle charging plugs are not universal throughout the world. However vehicles using one type of plug are generally able to charge at other types of charging stations through the use of plug adapters.

 
 
Wireless charging, either for stationary cars or as an electric road, is less common as of 2021, but is used in some cities for taxis.

<br/>
<br/>
<hr />
<br/>
<strong>Home charging : -</strong>
Electric cars are usually charged overnight from a home charging station; sometimes known as a charging point, wallbox charger, or simply a charger; in a garage or on the outside of a house. As of 2021 typical home chargers are 7 kW, but not all include smart charging. Compared to fossil fuel vehicles, the need for charging using public infrastructure is diminished because of the opportunities for home charging; vehicles can be plugged in and begin each day with a full charge. Charging from a standard outlet is also possible but very slow.
<br/>
<hr />
<strong>Public charging :- </strong>
Main article: Electric vehicle charging network
Public charging stations are almost always faster than home chargers with many supplying direct current to avoid the bottleneck of going through the car's AC to DC converter, as of 2021 the fastest being 350 kW.

Combined Charging System (CCS) is the most widespread charging standard, whereas the GB/T 27930 standard is used in China, and CHAdeMO in Japan. The United States has no de facto standard, with a mix of CCS, Tesla Superchargers, and CHAdeMO charging stations.
Some companies are building battery swapping stations, to substantially reduce the effective time to recharge.Some electric cars (for example, the BMW i3) have an optional gasoline range extender. The system is intended as an emergency backup to extend range to the next recharging location, and not for long-distance travel.
Sweden is planning to open the first permanent electric vehicle charging road by 2025. By early 2023, the chosen charging technology is expected to be announced. A standard for ground-level power supply electric roads is expected to be published by 14 November 2022.
                    </p>
                    <ul className="list-inline"> 
                    </ul>
                    <button className="btn btn-primary btn-xl text-uppercase" data-bs-dismiss="modal" type="button">
                      <i className="fas fa-xmark me-1" />
                      Close Project
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
      <script src="js/scripts.js"></script>
    </>
  )
};

export default Services;