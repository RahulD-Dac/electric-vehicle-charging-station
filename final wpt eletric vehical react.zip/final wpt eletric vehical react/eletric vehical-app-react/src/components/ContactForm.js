
import React from 'react';
import ReactDOM from 'react-dom';
import './style.css';

const ContactForm = () => {
  const [contactFormData, setContactFormData] = React.useState({});
  const [submitted, setSubmitted] = React.useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setContactFormData({ ...contactFormData, [name]: value });
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <React.Fragment>
      <form
        style={formStyle}
        onSubmit={(e) => handleFormSubmit(e)}
        name="contactForm"
        autoComplete="off"
      >
        <p style={formHeadingStyle}>Contact Form</p>
        <input
          required={true}
          style={inputFieldStyle}
          onChange={(e) => handleChange(e)}
          type="text"
          name="name"
          placeholder="Enter your name."
        />
        <input
          required={true}
          style={inputFieldStyle}
          onChange={(e) => handleChange(e)}
          type="email"
          name="email"
          placeholder="Enter your email."
        />
        <textarea
          rows={5}
          required={true}
          style={inputFieldStyle}
          onChange={(e) => handleChange(e)}
          name="message"
          placeholder="Enter your message."
        ></textarea>
        <button style={buttonStyle}>Submit</button>
      </form>

      {submitted && (
        <pre style={submittedStyle}>{JSON.stringify(contactFormData)}</pre>
      )}
    </React.Fragment>
  );
};

// Styles
const formStyle = {
  padding: "10px",
  maxWidth: "300px",
  margin: "0 auto"
};

const formHeadingStyle = {
  fontSize: "18px",
  textAlign: "center",
  marginBottom: "10px",
  fontWeight: "bold"
};

const inputFieldStyle = {
  border: "1px solid #ccc",
  fontSize: "14px",
  padding: "10px 8px",
  marginBottom: "10px",
  borderRadius: "5px",
  width: "100%",
  boxSizing: "border-box"
};

const buttonStyle = {
  padding: "10px",
  border: "unset",
  textTransform: "uppercase",
  backgroundColor: "#117ca6",
  color: "#ffffff",
  width: "100%",
  cursor: "pointer"
};

const submittedStyle = {
  backgroundColor: "#efefef",
  color: "#117ca6",
  textAlign: "center",
  margin: "0 auto",
  padding: "10px"
};

ReactDOM.render(
  <ContactForm title="Contact Form" />,
  document.getElementById("root")
);

export default ContactForm;