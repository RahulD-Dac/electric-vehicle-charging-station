import { Component } from 'react';
import { Container, Nav, Navbar } from 'react-bootstrap';
import { LinkContainer } from 'react-router-bootstrap';
export class NavigationBar extends Component {

         render() {
                  return (
                           <Navbar className="me-auto fixed-top" bg="light" expand="lg">
                                    <Container>
                                             <Navbar.Brand href="#home"> E-V App</Navbar.Brand>
                                             <Navbar.Toggle aria-controls="basic-navbar-nav " />
                                             <Navbar.Collapse id="basic-navbar-nav">
                                                      <Nav className="me-auto ">

                                                               <LinkContainer to={'/'}>
                                                                        <Nav.Link >Home</Nav.Link>
                                                               </LinkContainer >
                                                               <LinkContainer to={'/register'}>
                                                                        <Nav.Link  >RegisterForm</Nav.Link>
                                                               </LinkContainer  >
                                                               <LinkContainer to={'/login-from'}>
                                                                        <Nav.Link  >LoginForm</Nav.Link>
                                                               </LinkContainer  >
                                                               <LinkContainer to={'/findon-map'}>
                                                                        <Nav.Link  >Find On Map</Nav.Link>
                                                               </LinkContainer  >
                                                                
                                                      </Nav>
                                             </Navbar.Collapse>
                                    </Container>
                           </Navbar>
                  )
         }
}