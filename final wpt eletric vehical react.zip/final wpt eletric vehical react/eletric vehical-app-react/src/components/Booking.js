import React from 'react'

function Booking() {
  return (
    <div> <div className="bookpersonaldetail" style={{display: 'block'}}>
    <h5><span className="bookservicetitle"><span className="bookservicetoservice"><i className="icofont-long-arrow-left" /></span> Personal Detail</span></h5>
    <div className="card-body p-1">
      <div className="row form-group">
        <div className="col-lg-9 col-md-9 pl-0">
          <label htmlFor="recipient-name" className="col-form-label">Location: </label>
          <select id="userlocation" className="form-control">
            <option value>--Select City--</option>
            <option>New Delhi</option>
            <option>Bangalore</option>
            <option>Ahmedabad</option>
            <option>Kolkata</option>
            <option>Jaipur</option>
            <option>Chandigrah</option>
            <option>Chennai</option>
            <option>Noida</option>
            <option>Pune</option>
            <option>Guragaon</option>
            <option>Mumbai</option>
            <option>Anantapur</option>
            <option>Chittoor</option>
            <option>East Godavari</option>
            <option>Guntur</option>
            <option>Krishna</option>
            <option>Kurnool</option>
             
             
          
            <option>Patna</option>
            <option>Purnia</option>
            <option>Rohtas</option>
            <option>Saharsa</option>
            <option>Samastipur</option>
            <option>Saran</option>
            <option>Sheikhpura</option>
            <option>Sheohar</option>
          
            <option>Pellet Plant Jetty/Shiroda</option>
            <option>Talpona</option>
            <option>Vasco da Gama</option>
            <option>Amreli</option>
            <option>Anand</option>
            <option>Aravalli</option>
            <option>Banaskantha</option>
            <option>Bharuch</option>
            <option>Bhavnagar</option>
           
             
            <option>Thana</option>
            <option>Thane</option>
            <option>Trombay</option>
            <option>Varsova</option>
            <option>Vengurla</option>
            <option>Virar</option>
            <option>Wada</option>
           
             
             
          </select>
        </div>
        <div className="col-lg-9 col-md-9 pl-0">
          <label htmlFor="recipient-name"type="text" className="col-form-label">Name: </label>
          <input type="hidden" id="verifyretrofitmobile" defaultValue />
          <input type="hidden" id="verifyretrofitcls" defaultValue={0} />
          <input type="text" id="username" className="form-control" defaultValue />
        </div>
      </div>
      {/* <div className="form-group">
        <div className="row">
          <div className="col-lg-9 col-md-9 pl-0">
            <label htmlFor="message-text" className="col-form-label">Mobile: </label>
            <input type="number" id="mobile" className="form-control" oninput="changeretrofitstatus()" defaultValue />
            <input type="hidden" id="retrofitterhidid" />
          </div>
          <div className="col-lg-3 col-md-3 pl-0 pr-0">
            <label htmlFor="message-text" className="col-form-label w-100">&nbsp;</label>
            <button className="btn btn-info w-100" id="sendretrofitotp" onclick="verifyretrofitdealer()">Send OTP</button>
            <span className="editretrofitmob w-100" onclick="editretrofitmobnumber()">Edit</span>
          </div>
        </div>
      </div> */}
      {/* <div className="row mt-3 retronewevotpBox">
        <div className="col-lg-6 col-md-6 pl-0 verifyretrofitOtp" style={{display: 'none'}}><p>Please enter OTP to verify</p><div className="retrofitoptDnr"><p id="retrofitresend-btn" className="mb-1"><span className="retronocode">Didn't receive code? </span><a className id="resendretrofitotp_btn" onclick="resendretrofitotp()">Resend Code</a><span id="retrofitresend_success" /></p>
            <p id="retrofitopt-success">OTP has been sent successfully</p>
          </div></div>
        <div className="col-lg-6 col-md-6 pl-0 pr-1 verifyretrofitOtpbox" style={{display: 'none'}}>
          <div className="mb-3"><input maxLength={4} required name="otpField" className="sellevverifyinput w-75" id="verifiedretrofitinput" type="tel" defaultValue placeholder="- - - -" oninput="verifyretrofitotp(this.value)" /> <span id="retrofit_timer_div" /></div>
          <span className="redalert" style={{display: 'none'}} />
          <span className="greenalert" style={{display: 'none'}} />
        </div>
      </div> */}
    </div>
    <div className="cards-footer">
        <button type="button" id="showcarservicemobile" onclick="carbookservice()" data-service="Service" className="btn btn-primary  "  >Book Service</button>
      </div>
  </div></div>
  )
}

export default Booking