import axios from 'axios';

const BASE_URL = "http://127.0.0.1:5500/";

function getAllProductsFromServer(){
    // try{
    //     const response = await fetch(BASE_URL);
    //     const data = await response.json();
    //     return data;
    // }catch(error){
    //     console.log(error);
    // }
    return axios.get(`${BASE_URL}product`);
}

export function saveInfo(register){
    console.log(register);
    return axios.post(`${BASE_URL}Register`,register);
}

export function saveLoginInfo(login){
    console.log(login);
    return axios.post(`${BASE_URL}Login`,login);
}

export default getAllProductsFromServer
