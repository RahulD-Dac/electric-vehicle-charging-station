import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Home } from "./components/Home";
import { NavigationBar } from "./components/NavigationBar";
import Footer from "./components/Footer";
import RegisterForm from "./components/RegisterForm";
import LoginForm from "./components/LoginForm";
import FindStation from "./components/FindStation";
import Booking from "./components/Booking";
 function App() {
  return (
    <>
      <BrowserRouter>
        <NavigationBar></NavigationBar>

        <Routes>
          <Route path="/" element={<Home></Home>} />

          <Route path="/register" element={<RegisterForm ></RegisterForm>} />
          <Route path="/login-from" element={<LoginForm></LoginForm>} />
             <Route path="/findon-map" element={<FindStation ></FindStation>} />
       <Route path="/booking" element={<Booking></Booking>}/>
        </Routes>
      </BrowserRouter>
      <br />
      <br />
      <br />
      <Footer />
      <br />

    </>

  );
}

export default App;
