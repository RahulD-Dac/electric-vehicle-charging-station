import express from 'express';
import { createConnection } from 'mysql2';
import cors from 'cors';

const app = express();
app.use(express.json());
app.use(cors());

var conn = createConnection({
    host:"localhost",
    user:"root",
    password:"mysql",
    database:"client"
})

conn.connect((error,result)=>{
    if(error){
        console.log(error);
    } else {
        console.log("Database Connected");
    }
})

app.get("/product",(request, response)=>{
    var selectQry = "SELECT * FROM client";

    conn.query(selectQry,(error,result)=>{
        if(error){
            response.status(500).send({
                message:"Error in fetching the data"
            })
        } else {
            response.status(200).send(result)
        }
    })
})


// LOGIN AND REGISTRATION SECTION

app.post('/Register', (request, response) => {
    var insertQry = `insert into Register values('${request.body.username}',
        '${request.body.EmailAddress}',
        '${request.body.password}')`;
    
    conn.query(insertQry, (error,result) => { 
        if (error) {
            response.status(500).send({ message: "Error Found" });

        } else { 
            response.status(200).send({ message: "Sucefully Done" });
        }
    });

});
app.get('/Register', (req, res) => {
    var selectQry='select * from Register';
    conn.query(selectQry,(error,result)=>{
        if(error){
            response.status(500).send({message:'Error Occur'});
        }
        else{
            response.status(200).send(result);
        }
    })


});

app.post('/Login', (request, response) => {
    var insertQry = `insert into Login values(
            '${request.body.Email}',
            '${request.body.password}')`;
        
    conn.query(insertQry, (error,result) => { 
        if (error) {
            response.status(500).send({ message: "Error Found" });

        } else { 
            response.status(200).send({ message: "Sucefully Done" });
        }
    });

});


// ADMIN SECTION

app.delete("/admin/product/:id",(request,response) => {
    var deleteQry = `DELETE FROM productlist WHERE id = ${request.params.id}`;
    conn.query(deleteQry,(error,result)=>{
        if(error){
            response.status(500).send({
                message:"Error in deleting th product"
            });
        } else{
            response.status(200).send({
                message:`Product with ID: ${request.params.id} deleted succesfully`
            })
        }
    })
})

app.post("/admin/product",(request,response)=>{
    var InsertQry = `INSERT INTO productlist(id,brand,name,category,price,urlToImage) VALUES( ${request.body.id},
        '${request.body.brand}',
        '${request.body.name}',
        '${request.body.category}',
        ${request.body.price},
        '${request.body.urlToImage}')`

    conn.query(InsertQry,(error,result)=>{
        if(error){
            response.status(500).send({
                message:"Error while Inserting product"
            })
        } else{
            response.status(200).send({
                message:"Product Inserted Successfully"
            })
        }
    })
})


app.listen(5500,()=>{
    console.log("Listening to port 5500");
});





